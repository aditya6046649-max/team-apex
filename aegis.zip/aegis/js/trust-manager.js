/* AEGIS — Trust Manager
   Central orchestrator for the Zero-Trust policy enforcement */
const TrustManager = (() => {
  let isEnforcing = false;

  function handleAssessment(assessment) {
    if (isEnforcing) return;

    // Broadcast the new score to the UI
    document.dispatchEvent(new CustomEvent('aegis:trustUpdate', { detail: assessment }));

    if (assessment.state === 'CRITICAL') {
      isEnforcing = true;
      enforceRevocation(assessment);
    } else if (assessment.state === 'SUSPICIOUS') {
      enforceSuspicion(assessment);
    } else {
      clearSuspicion();
    }
  }

  function enforceRevocation(assessment) {
    console.warn('🚨 ZERO-TRUST POLICY TRIGGERED: Critical anomaly detected. Revoking session.');
    
    // 1. Log the security event
    const reason = assessment.reasons.length > 0 ? assessment.reasons.join(', ') : 'Critical behavioral anomaly';
    SecurityEvents.logEvent(assessment.riskScore, reason, 'Session Revoked');

    // 2. Revoke Auth Session
    AegisAuth.revokeSession(reason);

    // 3. Stop Telemetry
    BehaviorTracker.stop();

    // 4. Redirect to lockout screen (simulate the 401 response enforcement)
    window.location.href = 'lockout.html';
  }

  function enforceSuspicion(assessment) {
    console.log('⚠️ ZERO-TRUST POLICY: Suspicious behavior detected. Restricting features.');
    
    // Log if it just crossed the threshold
    const history = AnomalyEngine.getHistory();
    const prev = history.length > 1 ? history[history.length - 2] : null;
    if (!prev || prev.state !== 'SUSPICIOUS') {
       SecurityEvents.logEvent(assessment.riskScore, assessment.reasons[0] || 'Suspicious activity', 'Features Restricted');
    }

    // Trigger UI changes (handled by dashboard-app.js listening to 'aegis:suspicious')
    document.dispatchEvent(new CustomEvent('aegis:suspicious', { detail: assessment }));
  }

  function clearSuspicion() {
    // Trigger UI changes to restore features
    document.dispatchEvent(new CustomEvent('aegis:normal'));
  }

  return {
    initialize() {
      BehaviorTracker.onTelemetry((telemetry) => {
        const assessment = AnomalyEngine.evaluate(telemetry);
        handleAssessment(assessment);
      });
      BehaviorTracker.start();
    },
    shutdown() {
      BehaviorTracker.stop();
    }
  };
})();
