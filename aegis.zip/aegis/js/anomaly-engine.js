/* AEGIS — Anomaly Detection Engine
   Heuristic-based scoring to simulate Isolation Forest anomaly detection */
const AnomalyEngine = (() => {
  // Hardcoded baseline for demo (in production, this is built over time per user)
  const BASELINE = {
    wpm: 60,
    flightTime: 120, // ms
    mouseJitter: 5 // index
  };

  let history = [];

  function calculateRisk(telemetry) {
    let score = 50; // Base trust score (starts at 50 to simulate initial partial trust)
    let reasons = [];

    // 1. Keystroke Anomaly (WPM)
    if (telemetry.wpm > 0) {
      if (telemetry.wpm > 140) {
        // Impossible speed -> highly likely bot
        score += 40;
        reasons.push(`Superhuman typing speed (${telemetry.wpm} WPM)`);
      } else if (Math.abs(telemetry.wpm - BASELINE.wpm) > 40) {
        // Significant deviation
        score += 15;
        reasons.push(`Anomalous typing speed (${telemetry.wpm} WPM vs baseline ${BASELINE.wpm})`);
      } else {
        // Normal -> build trust
        score -= 5;
      }
    }

    // 2. Mouse Teleportation (Impossible movement)
    if (telemetry.teleportCount > 0) {
      score += Math.min(telemetry.teleportCount * 15, 50);
      reasons.push(`Impossible mouse teleportation detected (${telemetry.teleportCount}x)`);
    }

    // 3. Mouse Jitter (Erratic movement)
    if (telemetry.mouseJitter > BASELINE.mouseJitter * 3) {
      score += 20;
      reasons.push(`High mouse jitter index (${telemetry.mouseJitter})`);
    } else if (telemetry.mouseEvents > 10 && telemetry.mouseJitter <= BASELINE.mouseJitter * 1.5) {
      score -= 5; // Smooth movement builds trust
    }

    // 4. Flight Time Anomaly
    if (telemetry.avgFlightTime > 0) {
      if (Math.abs(telemetry.avgFlightTime - BASELINE.flightTime) > 80) {
        score += 10;
        reasons.push(`Irregular keystroke rhythm (${telemetry.avgFlightTime}ms flight)`);
      }
    }

    // Ensure score stays within 0-100 bounds
    const finalScore = Math.max(0, Math.min(100, score));
    
    // Determine state based on score
    // Note: Score here is "Risk Score", where higher is worse.
    // We will invert this for the UI "Trust Score" (Trust = 100 - Risk)
    let state = 'NORMAL';
    if (finalScore >= 90) state = 'CRITICAL';
    else if (finalScore >= 70) state = 'SUSPICIOUS';

    return {
      riskScore: finalScore,
      trustScore: 100 - finalScore,
      state: state,
      reasons: reasons,
      timestamp: Date.now()
    };
  }

  return {
    evaluate(telemetry) {
      // In a real system, we'd compare against the user's specific baseline in the DB.
      // Here we use the hardcoded baseline and immediate heuristics.
      const assessment = calculateRisk(telemetry);
      history.push(assessment);
      if (history.length > 50) history.shift(); // Keep last 50 evaluations
      return assessment;
    },
    getHistory() {
      return history;
    }
  };
})();
