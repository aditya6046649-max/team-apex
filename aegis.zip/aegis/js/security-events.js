/* AEGIS — Security Events System
   In-memory store simulating the PostgreSQL security_events table */
const SecurityEvents = (() => {
  const EVENTS_KEY = 'aegis_security_events';

  function getStoredEvents() {
    try {
      return JSON.parse(localStorage.getItem(EVENTS_KEY) || '[]');
    } catch {
      return [];
    }
  }

  function saveEvents(events) {
    localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
  }

  return {
    logEvent(riskScore, triggerReason, actionTaken) {
      const session = AegisAuth.getSession();
      const userId = session ? session.userId : 'anonymous';
      
      const newEvent = {
        id: 'evt_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        userId: userId,
        riskScore: riskScore,
        triggerReason: triggerReason,
        actionTaken: actionTaken,
        timestamp: new Date().toISOString()
      };

      const events = getStoredEvents();
      events.unshift(newEvent); // Add to beginning
      
      // Keep only last 100 events to simulate DB limit for demo
      if (events.length > 100) events.pop();
      
      saveEvents(events);

      // Notify UI
      document.dispatchEvent(new CustomEvent('aegis:newEvent', { detail: newEvent }));

      return newEvent;
    },

    getRecentEvents(limit = 10) {
      const session = AegisAuth.getSession();
      if (!session) return [];
      
      const events = getStoredEvents();
      return events
        .filter(e => e.userId === session.userId)
        .slice(0, limit);
    },

    clearEvents() {
      localStorage.removeItem(EVENTS_KEY);
    }
  };
})();
