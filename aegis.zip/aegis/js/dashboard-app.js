/* AEGIS — Dashboard UI Controller */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Auth Guard
  if (!AegisAuth.requireAuth()) return;
  const session = AegisAuth.getSession();
  document.getElementById('user-email').textContent = session.email;

  // 2. UI Elements
  const gaugeFill = document.getElementById('gauge-fill');
  const scoreVal = document.getElementById('trust-score-val');
  const statusLabel = document.getElementById('trust-status-label');
  const statusDesc = document.getElementById('trust-desc');
  const warningBanner = document.getElementById('warning-banner');
  const opsStatus = document.getElementById('ops-status');
  const statWpm = document.getElementById('stat-wpm');
  const statJitter = document.getElementById('stat-jitter');
  const eventLogEl = document.getElementById('event-log');

  // 3. Gauge Math (Circle circumference = 2 * PI * 45 = 282.7)
  const CIRCUMFERENCE = 283;
  
  function updateGauge(trustScore) {
    // Score is 0-100. Offset is 283 to 0.
    const offset = CIRCUMFERENCE - (trustScore / 100) * CIRCUMFERENCE;
    gaugeFill.style.strokeDashoffset = offset;
    scoreVal.textContent = trustScore;

    // Colors
    let color = 'var(--trust-safe)';
    let shadow = 'var(--shadow-glow-emerald)';
    
    if (trustScore < 30) {
      color = 'var(--trust-critical)';
      shadow = 'var(--shadow-glow-red)';
      statusLabel.textContent = 'Critical Alert';
      statusDesc.textContent = 'Session revocation imminent';
    } else if (trustScore <= 70) {
      color = 'var(--trust-warning)';
      shadow = 'none';
      statusLabel.textContent = 'Suspicious Activity';
      statusDesc.textContent = 'Verifying identity patterns';
    } else {
      statusLabel.textContent = 'Identity Verified';
      statusDesc.textContent = 'Behavior matches baseline';
    }

    gaugeFill.style.stroke = color;
    scoreVal.style.color = color;
    document.querySelector('.trust-gauge-container').style.textShadow = `0 0 20px ${color}`;
  }

  // Initial render
  updateGauge(50);
  renderEvents();

  // 4. Start Zero-Trust Engine
  TrustManager.initialize();

  // 5. Event Listeners
  
  // Listen for Trust Updates (Every 10s heartbeat)
  document.addEventListener('aegis:trustUpdate', (e) => {
    const assessment = e.detail;
    updateGauge(assessment.trustScore);
    
    // Update live stats visually with a little flash
    statWpm.innerHTML = `${BehaviorTracker.getTelemetry().wpm} <span style="font-size:0.6em; color:var(--text-muted)">WPM</span>`;
    statJitter.innerHTML = `${BehaviorTracker.getTelemetry().mouseJitter} <span style="font-size:0.6em; color:var(--text-muted)">IDX</span>`;
    
    statWpm.style.color = 'white';
    setTimeout(() => statWpm.style.color = '', 300);
  });

  // Listen for Suspicious State
  document.addEventListener('aegis:suspicious', () => {
    document.body.classList.add('state-suspicious');
    warningBanner.classList.add('active');
    
    opsStatus.className = 'badge badge-warning';
    opsStatus.textContent = 'Restricted Mode';
  });

  // Listen for Normal State
  document.addEventListener('aegis:normal', () => {
    document.body.classList.remove('state-suspicious');
    warningBanner.classList.remove('active');
    
    opsStatus.className = 'badge badge-safe';
    opsStatus.textContent = 'All Systems Go';
  });

  // Listen for New Events to render
  document.addEventListener('aegis:newEvent', () => {
    renderEvents();
  });

  // 6. UI Actions
  document.getElementById('btn-logout').addEventListener('click', () => {
    AegisAuth.signOut();
    window.location.href = 'index.html';
  });

  document.getElementById('btn-simulate').addEventListener('click', () => {
    BehaviorTracker.injectAttack();
    // Log it purely for UI feedback
    SecurityEvents.logEvent(100, 'Simulated intruder attack initiated', 'Tracking...');
  });

  // 7. Render Event Log
  function renderEvents() {
    const events = SecurityEvents.getRecentEvents(15);
    eventLogEl.innerHTML = '';
    
    if (events.length === 0) {
      eventLogEl.innerHTML = '<div style="color:var(--text-muted); text-align:center; padding: 2rem">No security events logged in current session.</div>';
      return;
    }

    events.forEach(evt => {
      const el = document.createElement('div');
      
      let severityClass = 'normal';
      if (evt.riskScore >= 90) severityClass = 'critical';
      else if (evt.riskScore >= 70) severityClass = 'suspicious';

      const time = new Date(evt.timestamp).toLocaleTimeString();

      el.className = `event-item ${severityClass} animate-slide-right`;
      el.innerHTML = `
        <div class="event-main">
          <div class="event-reason">${evt.triggerReason}</div>
          <div class="event-meta">${time} • Action: ${evt.actionTaken}</div>
        </div>
        <div class="event-score" style="color: var(--trust-${severityClass === 'normal' ? 'safe' : severityClass === 'suspicious' ? 'warning' : 'danger'})">
          Risk: ${evt.riskScore}
        </div>
      `;
      eventLogEl.appendChild(el);
    });
  }

  // 8. Live Stats polling (purely visual update between heartbeats)
  setInterval(() => {
    const t = BehaviorTracker.getTelemetry();
    if(t.wpm > 0) statWpm.innerHTML = `${t.wpm} <span style="font-size:0.6em; color:var(--text-muted)">WPM</span>`;
    if(t.mouseJitter > 0) statJitter.innerHTML = `${t.mouseJitter} <span style="font-size:0.6em; color:var(--text-muted)">IDX</span>`;
  }, 1000);
});
