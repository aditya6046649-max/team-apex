/* AEGIS — Behavioral Telemetry Engine
   Silently tracks keystroke dynamics and mouse movement patterns */
const BehaviorTracker = (() => {
  let keyTimes = [], keyDownMap = {}, mousePositions = [], dirChanges = 0;
  let lastMouseX = 0, lastMouseY = 0, lastDx = 0, lastDy = 0;
  let teleportCount = 0, active = false, listeners = [], heartbeatTimer = null;
  const HEARTBEAT_MS = 10000;
  const TELEPORT_THRESHOLD = 400; // pixels

  function onKeyDown(e) {
    const now = performance.now();
    if (!keyDownMap[e.key]) keyDownMap[e.key] = now;
  }

  function onKeyUp(e) {
    const now = performance.now();
    const downTime = keyDownMap[e.key];
    if (downTime) {
      keyTimes.push({ key: e.key, down: downTime, up: now, hold: now - downTime });
      delete keyDownMap[e.key];
    }
  }

  function onMouseMove(e) {
    const now = performance.now();
    const x = e.clientX, y = e.clientY;
    const dx = x - lastMouseX, dy = y - lastMouseY;
    const dist = Math.sqrt(dx * dx + dy * dy);

    // Detect teleportation (mouse jumping large distances instantly)
    if (dist > TELEPORT_THRESHOLD && mousePositions.length > 0) teleportCount++;

    // Detect abrupt direction changes (jitter)
    if (mousePositions.length > 1) {
      const dotProduct = dx * lastDx + dy * lastDy;
      if (dotProduct < 0) dirChanges++; // direction reversed
    }

    mousePositions.push({ x, y, t: now, dist });
    lastMouseX = x; lastMouseY = y; lastDx = dx; lastDy = dy;
  }

  function calcWPM() {
    if (keyTimes.length < 2) return 0;
    const window = keyTimes.filter(k => k.up > performance.now() - HEARTBEAT_MS);
    if (window.length < 2) return 0;
    const span = (window[window.length - 1].up - window[0].down) / 1000; // seconds
    const chars = window.length;
    return span > 0 ? Math.round((chars / 5) / (span / 60)) : 0;
  }

  function calcFlightTime() {
    if (keyTimes.length < 2) return 0;
    const recent = keyTimes.slice(-20);
    let total = 0, count = 0;
    for (let i = 1; i < recent.length; i++) {
      const flight = recent[i].down - recent[i - 1].up;
      if (flight > 0 && flight < 2000) { total += flight; count++; }
    }
    return count > 0 ? Math.round(total / count) : 0;
  }

  function calcMouseJitter() {
    const recent = mousePositions.filter(p => p.t > performance.now() - HEARTBEAT_MS);
    if (recent.length < 5) return 0;
    // Jitter = direction changes per movement sample
    const jitter = (dirChanges / Math.max(recent.length, 1)) * 100;
    return Math.min(Math.round(jitter * 10) / 10, 100);
  }

  function calcMouseVelocity() {
    const recent = mousePositions.filter(p => p.t > performance.now() - HEARTBEAT_MS);
    if (recent.length < 2) return 0;
    let totalDist = 0;
    for (let i = 1; i < recent.length; i++) totalDist += recent[i].dist;
    const timeSpan = (recent[recent.length - 1].t - recent[0].t) / 1000;
    return timeSpan > 0 ? Math.round(totalDist / timeSpan) : 0;
  }

  function collectTelemetry() {
    const data = {
      wpm: calcWPM(),
      avgFlightTime: calcFlightTime(),
      mouseJitter: calcMouseJitter(),
      mouseVelocity: calcMouseVelocity(),
      teleportCount: teleportCount,
      keyCount: keyTimes.filter(k => k.up > performance.now() - HEARTBEAT_MS).length,
      mouseEvents: mousePositions.filter(p => p.t > performance.now() - HEARTBEAT_MS).length,
      timestamp: Date.now()
    };
    // Reset counters for next window
    dirChanges = 0;
    teleportCount = 0;
    return data;
  }

  function heartbeat() {
    const telemetry = collectTelemetry();
    listeners.forEach(fn => fn(telemetry));
  }

  return {
    start() {
      if (active) return;
      active = true;
      document.addEventListener('keydown', onKeyDown);
      document.addEventListener('keyup', onKeyUp);
      document.addEventListener('mousemove', onMouseMove);
      heartbeatTimer = setInterval(heartbeat, HEARTBEAT_MS);
    },
    stop() {
      active = false;
      document.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('keyup', onKeyUp);
      document.removeEventListener('mousemove', onMouseMove);
      if (heartbeatTimer) clearInterval(heartbeatTimer);
    },
    onTelemetry(fn) { listeners.push(fn); },
    getTelemetry() { return collectTelemetry(); },
    // For demo: inject erratic data to simulate an attack
    injectAttack() {
      // Simulate bot-like typing (extremely fast)
      const now = performance.now();
      for (let i = 0; i < 50; i++) {
        keyTimes.push({ key: 'a', down: now + i * 10, up: now + i * 10 + 5, hold: 5 });
      }
      // Simulate mouse teleportation
      teleportCount += 8;
      dirChanges += 40;
      for (let i = 0; i < 30; i++) {
        mousePositions.push({
          x: Math.random() * 1920, y: Math.random() * 1080,
          t: now + i * 10, dist: 500 + Math.random() * 500
        });
      }
    }
  };
})();
