/* AEGIS — Auth System (localStorage-based JWT simulation) */
const AegisAuth = (() => {
  const USERS_KEY = 'aegis_users';
  const SESSION_KEY = 'aegis_session';
  const TOKEN_EXPIRY = 30 * 60 * 1000;

  function hash(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) { h = ((h << 5) - h) + s.charCodeAt(i); h |= 0; }
    return 'a_' + Math.abs(h).toString(36);
  }

  function makeToken(uid, email) {
    const hdr = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
    const pay = btoa(JSON.stringify({ sub: uid, email, iat: Date.now(), exp: Date.now() + TOKEN_EXPIRY }));
    return hdr + '.' + pay + '.' + btoa(hash(hdr + pay));
  }

  function decode(t) {
    try { return JSON.parse(atob(t.split('.')[1])); } catch { return null; }
  }

  function getUsers() { try { return JSON.parse(localStorage.getItem(USERS_KEY) || '{}'); } catch { return {}; } }

  return {
    signUp(email, pw) {
      if (!email || !pw) return { success: false, error: 'Email and password required.' };
      if (pw.length < 6) return { success: false, error: 'Password must be 6+ characters.' };
      const users = getUsers(); const e = email.toLowerCase().trim();
      if (users[e]) return { success: false, error: 'Account already exists.' };
      const uid = 'usr_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      users[e] = { id: uid, email: e, ph: hash(pw), createdAt: new Date().toISOString() };
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      const token = makeToken(uid, e);
      sessionStorage.setItem(SESSION_KEY, token);
      return { success: true, token, userId: uid };
    },
    signIn(email, pw) {
      if (!email || !pw) return { success: false, error: 'Email and password required.' };
      const users = getUsers(); const e = email.toLowerCase().trim();
      const u = users[e];
      if (!u) return { success: false, error: 'No account found.' };
      if (u.ph !== hash(pw)) return { success: false, error: 'Invalid password.' };
      const token = makeToken(u.id, e);
      sessionStorage.setItem(SESSION_KEY, token);
      return { success: true, token, userId: u.id };
    },
    isAuthenticated() {
      const t = sessionStorage.getItem(SESSION_KEY); if (!t) return false;
      const p = decode(t); return p && Date.now() < p.exp;
    },
    getSession() {
      const t = sessionStorage.getItem(SESSION_KEY); if (!t) return null;
      const p = decode(t); if (!p || Date.now() > p.exp) return null;
      return { userId: p.sub, email: p.email, issuedAt: p.iat, expiresAt: p.exp };
    },
    revokeSession(reason) {
      const s = this.getSession();
      const d = { userId: s?.userId || '?', email: s?.email || '?', revokedAt: new Date().toISOString(), reason };
      sessionStorage.setItem('aegis_revocation', JSON.stringify(d));
      sessionStorage.removeItem(SESSION_KEY);
      return d;
    },
    signOut() { sessionStorage.removeItem(SESSION_KEY); },
    getRevocationDetails() { try { return JSON.parse(sessionStorage.getItem('aegis_revocation') || 'null'); } catch { return null; } },
    requireAuth() { if (!this.isAuthenticated()) { window.location.href = 'index.html'; return false; } return true; }
  };
})();
